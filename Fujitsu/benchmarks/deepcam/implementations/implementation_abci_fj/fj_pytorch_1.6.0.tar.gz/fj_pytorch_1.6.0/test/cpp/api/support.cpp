#include <test/cpp/api/support.h>

namespace torch {
namespace test {

std::mutex AutoDefaultDtypeMode::default_dtype_mutex;

} // namespace test
} // namespace torch
