void dummy(int) { }
