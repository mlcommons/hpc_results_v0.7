#pragma once

#include <ATen/Tensor.h>
