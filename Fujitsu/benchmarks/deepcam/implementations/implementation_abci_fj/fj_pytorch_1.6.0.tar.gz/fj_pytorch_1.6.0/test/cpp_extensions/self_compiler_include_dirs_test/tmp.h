/* This is an empty header file that is used to test self.compiler.include_dirs with
 * relative path. To test, just inlucde this file into your source code and
 * add 'self_compiler_include_dirs_test' into 'include_dirs' in setuptools.setup.
 */
