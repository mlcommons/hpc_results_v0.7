#include <c10/core/Storage.h>

namespace c10 {

} // namespace c10
